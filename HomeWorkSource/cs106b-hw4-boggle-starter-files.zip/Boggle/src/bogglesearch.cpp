// This is the CPP file you will edit and turn in. (TODO: Remove this comment!)

#include <string>
#include "grid.h"
#include "lexicon.h"
#include "set.h"
#include "vector.h"
using namespace std;

Grid<char> generateRandomBoard(int size, const Vector<std::string>& letterCubes) {
    // TODO: write this function
    Grid<char> todo;   // this is only here so it will compile
    return todo;       // this is only here so it will compile
}

bool humanWordSearch(const Grid<char>& board, const Lexicon& dictionary, const string& word) {
    // TODO: write this function
    return false;   // this is only here so it will compile
}

Set<string> computerWordSearch(const Grid<char>& board, const Lexicon& dictionary, const Set<string>& humanWords) {
    // TODO: write this function
    Set<string> todo;   // this is only here so it will compile
    return todo;        // this is only here so it will compile
}
