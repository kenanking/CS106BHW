// This is the CPP file you will edit and turn in. (TODO: Remove this comment!)

#include "grid.h"
#include "vector.h"
#include "marbletypes.h"
#include "marbleutil.h"
#include "compression.h"
using namespace std;

bool solvePuzzle(Grid<Marble>& board, int marbleCount, Vector<Move>& moveHistory) {
    // TODO: write this function
    return false;   // this is only here so it will compile
}
