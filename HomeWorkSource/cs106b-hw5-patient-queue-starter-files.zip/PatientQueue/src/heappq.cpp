// You will edit and turn in this .cpp file.
// TODO: Remove this comment!

#include "heappq.h"

HeapPQ::HeapPQ() {
    // TODO: write this constructor
}

HeapPQ::~HeapPQ() {
    // TODO: write this destructor
}

void HeapPQ::clear() {
    // TODO: write this function
}

string HeapPQ::frontName() {
    // TODO: write this function
    return "";   // this is only here so it will compile
}

int HeapPQ::frontPriority() {
    // TODO: write this function
    return 0;   // this is only here so it will compile
}

bool HeapPQ::isEmpty() {
    // TODO: write this function
    return false;   // this is only here so it will compile
}

void HeapPQ::newPatient(string name, int priority) {
    // TODO: write this function
}

string HeapPQ::processPatient() {
    // TODO: write this function
    return "";   // this is only here so it will compile
}

void HeapPQ::upgradePatient(string name, int oldPriority, int newPriority) {
    // TODO: write this function
}

void HeapPQ::debug() {
    // TODO: write this function (optional)
}

ostream& operator <<(ostream& out, const HeapPQ& queue) {
    // TODO: write this function
    return out;
}
