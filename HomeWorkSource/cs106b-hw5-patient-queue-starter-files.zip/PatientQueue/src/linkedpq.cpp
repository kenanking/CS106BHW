// You will edit and turn in this .cpp file.
// TODO: Remove this comment!

#include "linkedpq.h"

LinkedPQ::LinkedPQ() {
    //TODO: write this constructor
}

LinkedPQ::~LinkedPQ() {
    // TODO: write this destructor
}

void LinkedPQ::clear() {
    // TODO: write this function
}

string LinkedPQ::frontName() {
    // TODO: write this function
    return "";   // this is only here so it will compile
}

int LinkedPQ::frontPriority() {
    // TODO: write this function
    return 0;   // this is only here so it will compile
}

bool LinkedPQ::isEmpty() {
    // TODO: write this function
    return false;   // this is only here so it will compile
}

void LinkedPQ::newPatient(string name, int priority) {
    // TODO: write this function
}

string LinkedPQ::processPatient() {
    // TODO: write this function
    return "";   // this is only here so it will compile
}

void LinkedPQ::upgradePatient(string name, int oldPriority, int newPriority) {
    // TODO: write this function
}

void LinkedPQ::debug() {
    // TODO: write this function (optional)
}

ostream& operator <<(ostream& out, const LinkedPQ& queue) {
    // TODO: write this function
    return out;
}
